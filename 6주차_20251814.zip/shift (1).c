﻿// shift.c
#include <stdio.h>

int main(void) {
	int num = 8;

	// 왼쪽 쉬프트 연산자를 사용하면 곱하기
	int mulBy2 = num << 1; // num * 2
	int mulBy4 = num << 2; // num * 4 (num * 2^2)
	int mulBy8 = num << 3; // num * 8 (num * 2^3)

	// 오른쪽 쉬프트 연산자를 사용하면 나누기
	int divBy2 = num >> 1; //num / 2
	int divBy4 = num >> 2; //num / 4 (num / 2^2)
	int divBy8 = num >> 3; //num / 8 (num / 2^3)
 
	// 결과 출력하기
	printf("Original: %d\n", num);
	printf("num << 1: %d\n", mulBy2);
	printf("num << 2: %d\n", mulBy4);
	printf("num << 3: %d\n", mulBy8);
	printf("num >> 1: %d\n", mulBy2);
	printf("num >> 2: %d\n", mulBy4);
	printf("num >> 3: %d\n", mulBy8);

	return 0;
	}